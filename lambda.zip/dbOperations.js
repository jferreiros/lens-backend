const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.LENS_TABLE_NAME;

const getLenses = async () => {
    const params = { TableName: TABLE_NAME };
    return dynamoDB.scan(params).promise();
};

const saveLens = async (item) => {
    const params = { TableName: TABLE_NAME, Item: item };
    return dynamoDB.put(params).promise();
};

const updateLens = async (id, data) => {
    const params = {
        TableName: TABLE_NAME,
        Key: { id },
        UpdateExpression: 'set frontRadius = :fr, backRadius = :br, thickness = :t, lensTitle = :lt',
        ExpressionAttributeValues: {
            ':fr': data.frontRadius,
            ':br': data.backRadius,
            ':t': data.thickness,
            ':lt': data.lensTitle
        },
        ReturnValues: 'UPDATED_NEW'
    };
    return dynamoDB.update(params).promise();
};

const deleteLens = async (id) => {
    const params = { TableName: TABLE_NAME, Key: { id }};
    return dynamoDB.delete(params).promise();
};

module.exports = { getLenses, saveLens, updateLens, deleteLens };
