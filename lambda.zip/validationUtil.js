const isValidLensData = (data) => {
    if (!data) return false;

    // Check for required fields
    const requiredFields = ['frontRadius', 'backRadius', 'thickness', 'lensTitle'];
    for (let field of requiredFields) {
        if (data[field] === undefined) return false;
    }

    // Validate data types and ranges
    if (typeof data.frontRadius !== 'number' || data.frontRadius < -2594 || data.frontRadius > 113.3) return false;
    if (typeof data.backRadius !== 'number' || data.backRadius < -2594 || data.backRadius > 113.3) return false;
    if (typeof data.thickness !== 'number' || data.thickness < 0 || data.thickness > 100) return false;
    if (typeof data.lensTitle !== 'string' || data.lensTitle.trim().length === 0) return false;

    return true;
};

module.exports = { isValidLensData };
