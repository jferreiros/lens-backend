// test/__mocks__/aws-sdk.js
const mockDynamoDB = {
    scan: jest.fn().mockReturnThis(),
    put: jest.fn().mockReturnThis(),
    update: jest.fn().mockReturnThis(),
    delete: jest.fn().mockReturnThis(),
    promise: jest.fn()
};

const AWS = {
    DynamoDB: jest.fn(),
    DynamoDB: {
        DocumentClient: jest.fn(() => mockDynamoDB)
    }
};

module.exports = AWS;
