const createResponse = (statusCode, body) => ({
    statusCode,
    headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "https://lens-project-seven.vercel.app", // Adjust this to match your frontend URL for tighter security
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST,PUT,GET"
    },
    body: JSON.stringify(body)
});

module.exports = { createResponse };
