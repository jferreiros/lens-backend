// lensHandler.js
const { v4: uuidv4 } = require('uuid');
const { getLenses, saveLens, updateLens, deleteLens } = require('./dbOperations');
const { createResponse } = require('./responseUtil');
const { isValidLensData } = require('./validationUtil');

exports.handler = async (event) => {
    try {
        switch (event.httpMethod) {
            case 'GET':
                const lenses = await getLenses();
                return createResponse(200, lenses.Items);

            case 'POST': {
                const data = JSON.parse(event.body);
                if (!isValidLensData(data)) {
                    return createResponse(400, { message: 'Invalid lens data' });
                }
                data.id = uuidv4();
                await saveLens(data);
                return createResponse(200, { message: 'Lens saved successfully', id: data.id });
            }

            case 'PUT': {
                const data = JSON.parse(event.body);
                if (!isValidLensData(data)) {
                    return createResponse(400, { message: 'Invalid lens data' });
                }
                await updateLens(data.id, data);
                return createResponse(200, { message: 'Lens updated successfully' });
            }

            case 'DELETE': {
                const { id } = event.pathParameters;
                if (!id) {
                    return createResponse(400, { message: 'Lens ID is required' });
                }
                await deleteLens(id);
                return createResponse(200, { message: 'Lens deleted successfully' });
            }

            default:
                return createResponse(405, { message: 'Method Not Allowed' });
        }
    } catch (error) {
        console.error('Error:', error);
        return createResponse(500, { message: 'Internal server error' });
    }
};
